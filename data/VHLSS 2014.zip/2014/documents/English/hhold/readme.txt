All the Muc.xls files correspond to individual sections on the VHLSS questionnaires.
The household questionnnaire.xls file contains all individual sections.
The can_doi(tn-ct) file describes how revenue/cost/income indicators are computed from the raw data.